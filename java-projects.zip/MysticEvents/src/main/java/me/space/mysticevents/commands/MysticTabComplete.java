package me.space.mysticevents.commands;

public class MysticTabComplete {
}
